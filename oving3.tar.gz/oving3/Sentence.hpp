#pragma once

void testSentence();
