#include <iostream>
#include "a.hpp"

int main() {
  a();
}
