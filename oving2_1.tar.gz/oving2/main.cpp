#include <iostream>

int main() {
  // Oppgave 1a
  int i = 3;
  int j = 5;
  int *p = &i;
  int *q = &j;
  
  std::cout << &i << " - " << i << std::endl;
  std::cout << &j << " - " << j << std::endl;
  std::cout << &p << " - " << p << std::endl;
  std::cout << &q << " - " << q << std::endl;
  /*
   * Eks utskrift:
   * 0x7fffabea5df0 - 3
   * 0x7fffabea5df4 - 5
   * 0x7fffabea5df8 - 0x7fffabea5df0
   * 0x7fffabea5e00 - 0x7fffabea5df4
   */
  
  // Oppgave 1b
  *p = 7;
  *q += 4;
  *q = *p + 1;
  p = q;
  std::cout << *p << " " << *q << std::endl;
  /*
   * Utskrift:
   * 8 8
   */
}
