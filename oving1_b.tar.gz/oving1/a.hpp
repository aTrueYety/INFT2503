#pragma once

void a();
