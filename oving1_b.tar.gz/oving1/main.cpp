#include <iostream>
#include "b.hpp"

double temps[4];


int main() {
  read_temperatures(temps, 4);
}
