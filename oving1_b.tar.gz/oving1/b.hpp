#pragma once

void read_temperatures(double temperatures[], int length);
