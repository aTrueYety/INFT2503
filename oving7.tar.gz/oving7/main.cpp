#include <iostream>
#include "fraction.hpp"
#include "task1.hpp"
#include "task2.hpp"

using namespace std;

int main() {
  cout << "####### Oppgave 1 #######" << endl;
  task1();
  cout << "\n\n\n\n####### Oppgave 2 #######" << endl;
  task2();
}
