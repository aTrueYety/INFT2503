#pragma once
#include "fraction.hpp"
#include <iostream>
#include <string>

void print(const std::string &text, const Fraction &broek);

void task1();
