#pragma once

void task1();

template <typename Type>
bool equal(Type, Type);
bool equal(double, double);
