#include "task1.hpp"
#include "task2.hpp"
#include <iostream>

int main() {
  task1();
  task2();
}
