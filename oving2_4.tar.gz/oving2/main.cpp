#include <iostream>
#include <cstring>


int main() {
  int a = 5;
  int &b = a; // «int &b;» er ikke lov fordi referanser må initialiseres ved deklarasjon
  int *c;
  c = &b;
  a = b + *c; // *a = *b + *c er ikke lov fordi man kun kan derefere (* prefix) en preker og a og b ikke er en peker.
  // &b = 2; prøver å tilordne en ny verdi til en adresse som ikke er lov
}
