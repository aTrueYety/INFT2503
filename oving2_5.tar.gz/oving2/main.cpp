#include <iostream>
#include <cstring>


int main() {
  double number = 4.5;
  double *p = &number;
  double &r = number;
  
  std::cout << number << " " << *p << " " << r << std::endl;
}
